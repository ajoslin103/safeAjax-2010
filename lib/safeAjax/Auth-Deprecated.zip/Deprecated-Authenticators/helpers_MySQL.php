<?php

//	MySQL_Helper - encapsulation of datbase routines
//
//	changelog, see allen @joslin .net for changes
//
//		04/01/09 - version 1.0: code collection from dev/test/debug
//		05/20/09 - version 2.0: rewrite/refactor, class-ify
//		06/12/09 - version 2.1: tag-along the ever-present JSON structure 

// ------------------------------------------------------------------------------------
class MySQL_Helper {

	var $db_hostn;
	var $db_dbnam;
	var $db_uname;
	var $db_pword;
	var $one_con;

	// ------------------------------------------------------------------------------------
	function MySQL_Helper ( $hoast, $dbas, $unam, $pwd ) 
	{
		$this->db_hostn = $hoast;
		$this->db_dbnam = $dbas;
		$this->db_uname = $unam;
		$this->db_pword = $pwd;
	}

	// ------------------------------------------------------------------------------------
	// database connection
	function conn ( &$json )
	{
		if ($this->one_con == null) {
			$this->open_db_json($json);
		}
		return $this->one_con;
	}

	// ------------------------------------------------------------------------------------
	// connect to database
	function open_db_json ( &$json )
	{
		$json['sqlError'] = "";
		
		$this->one_con = mysql_connect($this->db_hostn, $this->db_uname, $this->db_pword) 
			or $json['sqlError'] = mysql_error();

		mysql_select_db($this->db_dbnam)
			or $json['sqlError'] = mysql_error();
	}

	// ------------------------------------------------------------------------------------
	// select from database
	function db_select_json ( $query, &$json )
	{
		$json['sqlSuccess'] = false;
		$json['sqlError'] = "";
		
		if ($this->one_con == null) {
			$this->open_db_json($json);
		}

		if ($this->one_con != null) {

			$result = mysql_query($query)
				or $json['sqlError'] = mysql_error();
				
			if ($json['sqlError'] && $json['sqlDebug']) {
				$json['sqlStatement'] = $query;
			}

			if ($result) {
				$json['sqlSuccess'] = true;
				return $result;
			}
		}

		return null;
	}

	// ------------------------------------------------------------------------------------
	// select from database
	function db_select_cell_json ( $query, &$json )
	{                     
		$json['sqlSuccess'] = false;
		$json['sqlError'] = "";
		
		if ($this->one_con == null) {
			$this->open_db_json($json);
		}

		$cellValue = "";

		if ($this->one_con != null) {

			$result = mysql_query($query)
				or $json['sqlError'] = mysql_error();

			if ($json['sqlError'] && $json['sqlDebug']) {
				$json['sqlStatement'] = $query;
			}

			if ($result) {

				$json['sqlSuccess'] = true;
				if ($first_row = mysql_fetch_row($result)) {

					$cellValue = $first_row[0];
				}
			}
		}

		return $cellValue;
	}

	// ------------------------------------------------------------------------------------
	// update database
	function db_update_json ( $update, &$json )
	{
		$json['sqlSuccess'] = false;
		$json['sqlError'] = "";
		
		if ($this->one_con == null) {
			$this->open_db_json($json);
		}

		if ($this->one_con != null) {
			$result = mysql_query($update)
				or $json['sqlError'] = mysql_error();

			if ($json['sqlError'] && $json['sqlDebug']) {
				$json['sqlStatement'] = $update;
			}

			if ($result) {
				$json['sqlSuccess'] = true;
				return $result;
			}
		}

		return null;
	}

}

?>