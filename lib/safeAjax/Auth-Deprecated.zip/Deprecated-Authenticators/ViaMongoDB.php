<?php
ob_start();
require_once(dirname(__FILE__)."/Authenticator.interface.php"); 

//	safeAjax - connector creds checker class
//
//    version 1.0: code structure clone from ViaMongoDB to create ViaMongoDB

// ------------------------------------------------------------------------------------

class Authenticator extends SafeAjaxAuthenticator {
	
	// users: { id, deleted, access, username, password, persistence };
	
	var $dbConn;
	var $dbDebug = true;
	
	var $mongo_Conn;
	var $mongo_DB;

	// ------------------------------------------------------------------------------------
	function Authenticator () {

		try {
			
			$this->mongo_Conn = new Mongo("mongodb://localhost", array("connect" => false));

			try {
				
				$this->mongo_Conn->connect();
				
				try {

					$this->mongo_DB = $this->mongo_Conn->selectDB("userAuth");

					try {

						$this->dbConn = $this->mongo_DB->selectCollection("safeAjax");
						
						$this->isReady = true; // false by default
					}

					catch (Exception $ex) { $this->lastErr = $ex->getMessage(); }
				}

				catch (Exception $ex) { $this->lastErr = $ex->getMessage(); }
			}

			catch (Exception $ex) { $this->lastErr = $ex->getMessage(); }
		}

		catch (Exception $ex) { $this->lastErr = $ex->getMessage(); }
	}

	// ------------------------------------------------------------------------------------
	// if the given creds are good then allow access -- value's can [&should] arrive sha1(encrypted)
	function testLoginCreds ( $allegedUsername, $allegedPassword, &$json ) {

		if ($this->dbConn != null) {

			$json['dbDebug'] = $this->dbDebug;

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {

				$json['freshCookie'] = false;
				$json['tastedCookie'] = $json['sa_CookieName'];
				return $this->accessGranted($json);

			} else {

				$safeUsername = (get_magic_quotes_gpc())? $allegedUsername: addslashes($allegedUsername); 
				$safePassword = (get_magic_quotes_gpc())? $allegedPassword: addslashes($allegedPassword);
				
				if (! empty($json['sha1Logins'])) {
					$safeUsername = ($json['sha1Logins'])? sha1($safeUsername): $safeUsername;
					$safePassword = ($json['sha1Logins'])? sha1($safePassword): $safePassword;
				}

				if ($allegedUser = $this->dbConn->findOne( array( 'deleted' => array( '$ne' => 1 ), 'username' => $safeUsername, 'password' => $safePassword ) )) {
					$allegedUser['id'] = (String)$allegedUser['_id'];
					
					if ($this->dbConn->update(array("_id" => $allegedUser['_id']), array('$set' => array('persistence' => $this->makeCookieValue($json['sa_Duration']))) ) ) {

						$this->bakeCookie($json['sa_CookieDomain'],$json['sa_CookiePath'],$json['sa_CookieName'],$json['sa_Duration']);
						$json['bakedCookie'] = $json['sa_CookieName'];
						$json['freshCookie'] = true;

						return $this->accessGranted($json);
					}
				}
			}
		}

		return parent::testLoginCreds($allegedUsername,$allegedPassword,$json);
	}

	// ------------------------------------------------------------------------------------
	// check access level  
	function testAccessLevel ( $requestedLevel, &$json ) {
		
		$json['dbDebug'] = $this->dbDebug;

		if ($requestedLevel == 0) { return $this->accessGranted($json); }
		if ($this->dbConn != null) {

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {
				
				if ($allegedUserLevelCookie = $this->getACookie($json['sa_CookieName'])) {

					$safeUserLevelCookie = (get_magic_quotes_gpc())? $allegedUserLevelCookie : addslashes($allegedUserLevelCookie);
					if ($allegedUser = $this->dbConn->findOne( array( 'deleted' => array( '$ne' => 1 ), 'persistence' => $safeUserLevelCookie ) )) {

						if ($requestedLevel < $allegedUser['access']) { 

							$json['freshCookie'] = false;
							$json['tastedCookie'] = $json['sa_CookieName'];
							return $this->accessGranted($json);
						}
					}
				}
			}

			return $this->accessDenied($json);
		}
	}

}

// ------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------

// 
// done
// 

ob_end_flush();
?>