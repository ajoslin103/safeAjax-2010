<?php
ob_start();

//	safeAjax - connector creds checker
//
//	I wrote this connector to safeguard my ajax communications.  
//
//	It's originally based upon chris shifletts article: the truth about sessions 
//
//	changelog, see allen @joslin .net for changes
//
//		version 4: changes for code re-arrangements, added cookieValue creation
//    version 3: rebuilt cookies for adjustable duration
//	   version 2.1: combine reader & writer into one object
//	   version 2.0: rewrite/refactor, support accessLevels and registration
//	   version 1.0: code collection from dev/test/debug
//
//             - SafeAjaxAuthenticator: base class, no access allowed by default

// ------------------------
class SafeAjaxAuthenticator {
	
	var $isReady;
	var $lastErr;

	// ------------------------------------------------------------------------------------
	function SafeAjaxAuthenticator () { $this->isReady = false; $this->lastErr = ""; }

	// ------------------------------------------------------------------------------------
	function isReady () { return $this->isReady; }

	// ------------------------------------------------------------------------------------
	function lastError () { return $this->lastErr; }

	// ------------------------------------------------------------------------------------
	function makeCookieValue ( $duration ) 
	{ 
		// this cookie is good for the duration (by a well-behaved browser), 
		//	  until the session changes, or until midnight -- whichever comes first
		$today = getdate(); $salt = $today['yday'] . $duration;
		return sha1($salt . session_id() . $_SERVER['HTTP_USER_AGENT']);
	}

	// ------------------------------------------------------------------------------------
	// this tests cookie values against a predictable value
	function tasteCookie ( $requestedCookieName, $requestedCookieDuration )
	{
		if (empty($_COOKIE[$requestedCookieName])) { return false; }
		return ($this->makeCookieValue($requestedCookieDuration) != $_COOKIE[$requestedCookieName])? false: true;
	}

	// ------------------------------------------------------------------------------------
	// this returns the value from a named cookie
	function getACookie ( $theCookieName )
	{
		if (! isset($_COOKIE[$theCookieName])) { return false; }
		return (isset($_COOKIE[$theCookieName]))? $_COOKIE[$theCookieName]: "null";
	}

	// ------------------------------------------------------------------------------------
	// this writes cookie values based upon defined requested types
	function bakeCookie ( $requestedCookieDomain, $requestedCookiePath, $requestedCookieName, $requestedCookieDuration )
	{
		setcookie($requestedCookieName, $this->makeCookieValue($requestedCookieDuration), time() + $requestedCookieDuration, $requestedCookiePath, ".".$requestedCookieDomain);
	}

	// ------------------------------------------------------------------------------------
	// NOTE: this function MUST be overridden in the usage class
	function testAccessLevel ( $requestedLevel, &$json )
	{
		return $this->accessDenied(&$json);
	}

	// ------------------------------------------------------------------------------------
	// given a username and password it checks for validity NOTE: this function MUST be overridden in the usage class
	function testLoginCreds ( $allegedUsername, $allegedPassword, &$json  )
	{
		return $this->accessDenied(&$json);
	}

	// ------------------------------------------------------------------------------------
	// grant access
	function accessGranted ( &$json )
	{
		$json['authRequires'] = "Resource Access Granted.";		
		$json['authOK'] = true;
		return true;
	}

	// ------------------------------------------------------------------------------------
	// deny access
	function accessDenied ( &$json )
	{
		$json['authRequires'] = "Login is required to access this resource.";		
		$json['authOK'] = false;
		return false;
	}

}

ob_end_flush();
?>