<?php
ob_start();

$GLOBALS['THRIFT_ROOT'] = dirname(dirname(dirname(__FILE__))).'/phpcassa-0.1/thrift';
require_once $GLOBALS['THRIFT_ROOT'].'/packages/cassandra/Cassandra.php';
require_once $GLOBALS['THRIFT_ROOT'].'/packages/cassandra/cassandra_types.php';
require_once $GLOBALS['THRIFT_ROOT'].'/transport/TSocket.php';
require_once $GLOBALS['THRIFT_ROOT'].'/protocol/TBinaryProtocol.php';
require_once $GLOBALS['THRIFT_ROOT'].'/transport/TFramedTransport.php';
require_once $GLOBALS['THRIFT_ROOT'].'/transport/TBufferedTransport.php';

require_once(dirname(__FILE__)."/Authenticator.interface.php"); 

require_once(dirname($GLOBALS['THRIFT_ROOT'])."/phpcassa.php"); 
require_once(dirname($GLOBALS['THRIFT_ROOT'])."/uuid.php"); 

//	safeAjax - connector creds checker class
//
//    version 1.0: code structure clone from ViaMongoDB to create ViaCassandra

DEFINE('ViaCassandra_Keyspace','safeAjax');

// ------------------------------------------------------------------------------------

class Authenticator extends SafeAjaxAuthenticator {

	// SafeAjaxAuthenticator:: var $isReady;
	// SafeAjaxAuthenticator:: var $lastErr;
	
	//	<Keyspace Name="safeAjax">
	// 	<ColumnFamily Name="userEMail" CompareWith="UTF8Type" />			<!-- key: EMail, values: userId -->
	// 	<ColumnFamily Name="userData" CompareWith="UTF8Type" />			<!-- key: userId, values: access, username, password, persistence, EMail, roles -->
	// 	<ColumnFamily Name="userLogin" CompareWith="UTF8Type" />			<!-- key: username, values: userId -->
	// 	<ColumnFamily Name="userPersistence" CompareWith="UTF8Type" />	<!-- key: persistence, values: userId -->
	//	</Keyspace>
	
	var $dbConn;
	var $dbDebug = true;

	// ------------------------------------------------------------------------------------
	function Authenticator ( $nodeArray=array( 'localhost' => '9160' ) ) {

		try {

			foreach ( array_keys($nodeArray) as $nodeName ) {
				CassandraConn::add_node($nodeName,$nodeArray[$nodeName]);
			}
			
			$this->dbConn = array();
			
			$this->dbConn['userData'] = new CassandraCF(ViaCassandra_Keyspace, 'userData'); // ColumnFamily
			$this->dbConn['userLogin'] = new CassandraCF(ViaCassandra_Keyspace, 'userLogin'); // ColumnFamily
			$this->dbConn['userPersistence'] = new CassandraCF(ViaCassandra_Keyspace, 'userPersistence'); // ColumnFamily
			
			$this->isReady = ( ($this->dbConn['userData']) && ($this->dbConn['userLogin']) && ($this->dbConn['userPersistence']) ); // false by default
		}

		catch (Exception $ex) { $this->lastErr = $ex->getMessage(); }
	}

	// ------------------------------------------------------------------------------------
	// protect a string -- against attempted embedded database manipulations
	function dbSafe ( $inputStr ) {
		return (get_magic_quotes_gpc())? $inputStr: addslashes($inputStr);
	}

	// ------------------------------------------------------------------------------------
	// if the given creds are good then allow access -- value's can [&should] arrive sha1(encrypted)
	function testLoginCreds ( $allegedUsername, $allegedPassword, &$json ) {

		if ($this->dbConn != null) {

			$json['dbDebug'] = $this->dbDebug;

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {

				$json['freshCookie'] = false;
				$json['tastedCookie'] = $json['sa_CookieName'];
				return $this->accessGranted($json);

			} else {

				$safeUsername = (get_magic_quotes_gpc())? $allegedUsername: addslashes($allegedUsername); 
				$safePassword = (get_magic_quotes_gpc())? $allegedPassword: addslashes($allegedPassword);

				if (! empty($json['sha1Logins'])) {
					$safeUsername = ($json['sha1Logins'])? sha1($safeUsername): $safeUsername;
					$safePassword = ($json['sha1Logins'])? sha1($safePassword): $safePassword;
				}

				try {
					
					if ($allegedLogin = $this->dbConn['userLogin']->get((String)$safeUsername)) { 
						if (empty($allegedLogin)) { $json['tal-05'] = "allegedLogin empty"; return $this->accessDenied($json); }
						
						if ($allegedUser = $this->dbConn['userData']->get((String)$allegedLogin['userData'])) { 

							if ($allegedUser['password'] == "$safePassword") {

								$newPersistence = $this->makeCookieValue($json['sa_Duration']);
								$json['newPersistence'] = $newPersistence;

								try {

									$this->dbConn['userPersistence']->insert((String)$newPersistence, array( 'userData' => $allegedLogin['userData'] ));

									if (! empty($allegedUser['persistence'])) {
										try { $this->dbConn['userPersistence']->remove($allegedUser['persistence']); }
										catch (Exception $ex) { $json['cassErr'] = "tlc-04: ". $ex->getMessage(); }
									}

									try {

										$this->dbConn['userData']->insert((String)$allegedLogin['userData'], array( 'persistence' => $newPersistence ));

										$this->bakeCookie($json['sa_CookieDomain'],$json['sa_CookiePath'],$json['sa_CookieName'],$json['sa_Duration']);
										$json['bakedCookie'] = $json['sa_CookieName'];
										$json['freshCookie'] = true;

										return $this->accessGranted($json);
									}

									catch (Exception $ex) { $json['cassErr'] = "tlc-03: ". $ex->getMessage(); }

								}

								catch (Exception $ex) { $json['cassErr'] = "tlc-02: ". $ex->getMessage(); }
							}
						}
					}
				}

				catch (Exception $ex) { $json['cassErr'] = "tlc-01: ". $ex->getMessage(); }
			}
		}

		return parent::testLoginCreds($allegedUsername,$allegedPassword,$json);
	}

	// ------------------------------------------------------------------------------------
	// check access level  
	function testAccessLevel ( $requestedLevel, &$json ) {
		
		$json['dbDebug'] = $this->dbDebug;

		if ($requestedLevel == 0) { return $this->accessGranted($json); }
		if ($this->dbConn != null) {

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {
				
				if ($allegedUserLevelCookie = $this->getACookie($json['sa_CookieName'])) {

					$safeUserLevelCookie = (get_magic_quotes_gpc())? $allegedUserLevelCookie : addslashes($allegedUserLevelCookie);

					try {

						$allegedPersistence = $this->dbConn['userPersistence']->get((String)$safeUserLevelCookie);
						if (empty($allegedPersistence)) { $json['tal-03'] = "allegedPersistence empty"; return $this->accessDenied($json); }
						
						try {

							$allegedUser = $this->dbConn['userData']->get((String)$allegedPersistence['userData']);

							if ($requestedLevel < $allegedUser['access']) { 

								$json['freshCookie'] = false;
								$json['tastedCookie'] = $json['sa_CookieName'];
								return $this->accessGranted($json);
							}
						}

						catch (Exception $ex) { $json['cassErr'] = "tal-02: ". $ex->getMessage(); }
					}

					catch (Exception $ex) { $json['cassErr'] = "tal-01: ". $ex->getMessage(); }
				}
			}
			
			return $this->accessDenied($json);
		}
	}

}

// ------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------

// 
// done
// 

ob_end_flush();
?>