<?php
ob_start();
require_once(dirname(__FILE__)."/Authenticator.interface.php"); 
require_once(dirname(__FILE__)."/helpers_MySQL.php"); 

//	safeAjax - connector creds checker class
//
//    version 3: rebuilt for adjustable duration 
//	   version 2.1: combine reader & writer into one object
//	   version 2.0: rewrite/refactor, support accessLevels and registration
//	   version 1.0: code collection from dev/test/debug

// ------------------------------------------------------------------------------------

class Authenticator extends SafeAjaxAuthenticator {

	// CREATE TABLE IF NOT EXISTS `tbl_users` (
	//   `id` int(11) NOT NULL auto_increment,
	//   `access` int(11) NOT NULL default '0',
	//   `username` varchar(32) NOT NULL default '',
	//   `password` varchar(64) NOT NULL default '',
	//   `persistence` varchar(64) NOT NULL default '',
	//   PRIMARY KEY  (`id`)
	// ) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

	// ------------------------------------------------------------------------------------
	function Authenticator () {

		$this->dbConn = new MySQL_Helper("localhost", "safeAjax", "safeAjax", "safeAjax");
		if ($this->dbConn == null ) {
			print "<!-- safeAjax internal error: 'dbConn' did not instantiate in MySQL_Helper -->";
			$json['safeAjaxError'] = "safeAjax internal error: 'dbConn' did not instantiate";
		} else {
			$this->isReady = true; // default is false
		}
	}

	// ------------------------------------------------------------------------------------
	// if the given creds are good then allow access -- value's can [&should] arrive sha1(encrypted)
	function testLoginCreds ( $allegedUsername, $allegedPassword, &$json ) {

		if ($this->dbConn != null) {

			$json['dbDebug'] = $this->dbDebug;

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {

				$json['freshCookie'] = false;
				$json['tastedCookie'] = $json['sa_CookieName'];
				return $this->accessGranted($json);

			} else {

				$safeUsername = mysql_real_escape_string($allegedUsername,$this->dbConn->conn($json)); 
				$safePassword = mysql_real_escape_string($allegedPassword,$this->dbConn->conn($json));
				
				if (! empty($json['sha1Logins'])) {
					$safeUsername = ($json['sha1Logins'])? sha1($safeUsername): $safeUsername;
					$safePassword = ($json['sha1Logins'])? sha1($safePassword): $safePassword;
				}
				
				$selectSQL = " select * from tbl_users where deleted = 0 and username = '$safeUsername' and password = '$safePassword' limit 1";
				if ($selectResult = $this->dbConn->db_select_json($selectSQL,$json)) { 

					if ($allegedUser = mysql_fetch_assoc($selectResult)) {

						$updateSQL = " update tbl_users set persistence = '".$this->makeCookieValue($json['sa_Duration'])."' where id = ".$allegedUser['id'];
						$updateResult = $this->dbConn->db_update_json($updateSQL,$json);

						$this->bakeCookie($json['sa_CookieDomain'],$json['sa_CookiePath'],$json['sa_CookieName'],$json['sa_Duration']);
						$json['bakedCookie'] = $json['sa_CookieName'];
						$json['freshCookie'] = true;

						return $this->accessGranted($json);

					}
				}
			}
		}

		return parent::testLoginCreds($allegedUsername,$allegedPassword,$json);
	}

	// ------------------------------------------------------------------------------------
	// check access level  
	function testAccessLevel ( $requestedLevel, &$json ) {
		
		$json['dbDebug'] = $this->dbDebug;

		if ($requestedLevel == 0) { return $this->accessGranted($json); }
		if ($this->dbConn != null) {

			if ($this->tasteCookie($json['sa_CookieName'],$json['sa_Duration'])) {
				
				if ($allegedUserLevelCookie = $this->getACookie($json['sa_CookieName'])) {
					
					$safeUserLevelCookie = mysql_real_escape_string($allegedUserLevelCookie,$this->dbConn->conn($json));
					$selectSQL = " select * from tbl_users where deleted = 0 and persistence = '$safeUserLevelCookie' limit 1";
					if ($selectResult = $this->dbConn->db_select_json($selectSQL,$json)) {
						if ($allegedUser = mysql_fetch_assoc($selectResult)) {

							if ($requestedLevel < $allegedUser['access']) { 

								$json['freshCookie'] = false;
								$json['tastedCookie'] = $json['sa_CookieName'];
								return $this->accessGranted($json);
							}
						}
					}
				}
			}

			return $this->accessDenied($json);
		}

	}

}

// ------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------

// 
// done
// 

ob_end_flush();
?>